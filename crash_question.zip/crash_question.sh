#!/usr/bin/expect -f
set timeout -1

spawn ./question
expect "Enter the count of numbers? "
send "1234567890123456789123456789\r"
expect eof
