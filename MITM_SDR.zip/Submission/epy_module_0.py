from gnuradio import gr
#gr.logger_config(filename,watch_period)  # Configures the logger with conf file filename
names = gr.logger_get_names()  # Returns the names of all loggers
gr.logger_reset_config()   # Resets logger config by removing all appenders


log=gr.logger("names[2]")
log.debug("Log a debug message")
log.set_level("EMERG")
#print(names)
