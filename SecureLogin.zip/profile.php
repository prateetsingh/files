<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Secure Coding Profile</title>
  </head>
  <?php
      session_start();
      $id=$_SESSION['id'];
      echo '<script type="text/javascript">
                    alert("Please click ok to Continue");;
                    </script>';
      if(!(isset($_SESSION['id']))){
        header("Location: login.php");  
      }
      
        if(isset($_POST['logout']))
        {
            unset($_SESSION['id']);
            session_destroy();
            header("Location: login.php");
        }            
?>
<body>
<div class="container py-2">
    <div class="jumbotron">
        <h1>User Profile</h1>
        <h2>You have succesfully Logged in to your Account</h2>
        <form method="POST" action="profile.php" >
            <div class="form-group">
                <button name="logout" class="btn btn-danger">Log out</button>
            </div>
        </form>
    <div>
<div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
      
