<?php
session_start();
session_destroy();
include('connection.php');
if(isset($_POST['submit']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    
    //$checkid="select * from students where username='$username' ";
    $stmt = $con->prepare("select * from students where username=?");
    $stmt->bind_param('s',$username);
    
    //$run_checkid=mysqli_query($con,$checkid);
    $stmt->execute();

    $query_run = $stmt->get_result();      
    $row=$query_run->fetch_assoc();
    $n_rows = $query_run->num_rows;
    //echo $run_checkid[password];
    if($n_rows!=0)
    {
        $dpassword=$row['password'];
        if($dpassword==$password)
        {   session_start();
            $_SESSION['id']=$row['id'];
            echo '<script type="text/javascript">
                    alert("Login Succesful");
                    window.location.assign("profile.php");
                    </script>';
            
            
        }
        else
        {
            echo '<script type="text/javascript">
                    alert("Wrong Credentials");
                    window.location.assign("login.php");
                    </script>';
        }
        
    }
    else
    {   
        echo '<script type="text/javascript">
                    alert("Wrong Credentials");
                    window.location.assign("login.php");
                    </script>';
    }
}

?>

<html>
<head>
<title> Login Page</title>
</head>
<body>
    <form method='post' enctype='multipart/form-data'>
        <input type='text' name='username' placeholder='Username' required />
        <input type='password' name='password' placeholder='Password' required />
        <input type='submit' name='submit' value='Login' />
    </form>


</body>
</html>

