<?php
    $servername="localhost";
    $username="root";
    $password="";
    $database="students";
    $con=mysqli_connect($servername,$username,$password,$database);


//    if($con)
/*    {
        echo "connection is successful";        
    }
    else
    {
        echo "Connection Failed";
    }
*/

?>

