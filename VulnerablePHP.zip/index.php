<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Secure Coding</title>
  </head>
  <body>
  <div class="container py-2">
    <div class="jumbotron">
      <h1>Login</h1>
      <form  method="POST" action="index.php">
        <div class="form-group">
          <label>Username</label>
          <input type="text" class="form-control" name="username" placeholder="Enter Username">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" class="form-control" name="password" placeholder="Enter Password">
        </div>
        <div class="form-group">
          <button class="btn btn-success" type="submit" name="submit">Login</button>
        </div>
      </form>
    </div>
  </div>
  <?php
    session_start();
    session_destroy();
    include('connection.php');
    if(isset($_POST['submit']))
    {
        $username=$_POST['username'];
        $password=$_POST['password'];
        
        //$checkid="select * from students where username='$username' ";
        //use prepare
        $query = $connection->prepare("select * from students where username=?");
        $query->bind_param('s',$username);
        
        //$run_checkid=mysqli_query($con,$checkid);
        $query->execute();
    
        $query_run = $query->get_result();      
        $row=$query_run->fetch_assoc();
        $n_rows = $query_run->num_rows;

      if($n_rows!=0)
    {
        $dpassword=$row['password'];
        if($dpassword==$password)
        {
            echo '<script type="text/javascript">
                    alert("Login Succesful");
                    window.location.assign("profile.php");
                    </script>';
            
            session_start();
            $_SESSION['id']=$row['id'];
        }
        else
        {
            echo '<script type="text/javascript">
                    alert("Incorrect Credentials");
                    window.location.assign("index.php");
                    </script>';
        }
        
    }
    else
    {   
        echo '<script type="text/javascript">
                    alert("Incorrect Credentials");
                    window.location.assign("index.php");
                    </script>';
    }
    }
  

  ?>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  </body>
</html>
