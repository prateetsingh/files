----------------------------------RealTime Audio Tx-Rx--------------------------------

Please specify the wav file location in 'Wav File Source' block and enable the following 
blocks to transmit test.wav file - :
--- Wav File Source
--- Multiple Const
--- Add

And delete the bypass for 'Add' block for 'NBFM Transmit' & 'QT GUI Waterfall Sink'.


